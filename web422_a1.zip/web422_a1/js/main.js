

$(document).ready(function(){
    console.log("jquery working!");
    $("a").on("click", function(event) {
        event.preventDefault();

        $.ajax({
            url: "https://infinite-spire-95987.herokuapp.com/teams",
            type: "GET",
            contentType: "application/json"
        }).done(function(data){
            $(".well").empty().append("<h3>Teams</h3>").append(JSON.stringify(data));
        })
        .fail(function(err){});


    });
});