import { Component, OnInit } from '@angular/core';
import { ChatService } from '../chat.service';

@Component({
  selector: 'app-chat-window',
  templateUrl: './chat-window.component.html',
  styleUrls: ['./chat-window.component.css']
})
export class ChatWindowComponent implements OnInit {
  private getMessagesSub: any;
  messagesArray: string[] = ["a", "b"];
  currentMessage: string;

  constructor(private chatService: ChatService) {}

  ngOnInit() {
    this.getMessagesSub = this.chatService.getMessages;

    // TODO: check subscribing code
    this.getMessagesSub.subscribe((msg) => {
      console.log("TO PUSH:" + msg);
      console.log("Typeof:" + typeof(this.messagesArray));
      console.log(this.messagesArray);
      this.messagesArray = msg;
    });
  }

  sendMessage(){
    this.chatService.sendMessage(this.currentMessage);
    this.currentMessage = "";
  }

  ngOnDestroy(){
    if(this.getMessagesSub){this.getMessagesSub.unsubscribe();}
  }

}
